package com.example.numberconversion

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var inputDec: EditText
    private lateinit var inputBin: EditText
    private lateinit var inputOct: EditText
    private lateinit var inputHex: EditText
    private lateinit var btnConvert: Button
    private lateinit var btnClear: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        inputDec = findViewById(R.id.input_decimal)
        inputBin = findViewById(R.id.input_binary)
        inputOct = findViewById(R.id.input_octal)
        inputHex = findViewById(R.id.input_hexa)
        btnConvert = findViewById(R.id.btn_convert)
        btnClear = findViewById(R.id.btn_clear)

        btnConvert.setOnClickListener(this)
        btnClear.setOnClickListener(this)
    }

    override fun onClick(v: View) {
        if(v.id == R.id.btn_convert) {
            val inputDesimal = inputDec.text.toString().trim()
            val inputBiner = inputBin.text.toString().trim()
            val inputOktal = inputOct.text.toString().trim()
            val inputHexa = inputHex.text.toString().trim()

            if (inputDesimal.isNotEmpty()) {
                val desimal = inputDesimal.toInt()
                val biner = desimal.toString(2)
                input_binary.setText(biner)
                val okta = desimal.toString(8)
                input_octal.setText(okta)
                val hexa = desimal.toString(16).toUpperCase()
                input_hexa.setText(hexa)

            } else if (inputBiner.isNotEmpty()) {
                val biner = inputBiner.toInt(2)
                val desimal = biner.toString(10)
                input_decimal.setText(desimal)
                val okta = biner.toString(8)
                input_octal.setText(okta)
                val hexa = biner.toString(16).toUpperCase()
                input_hexa.setText(hexa)

            } else if (inputOktal.isNotEmpty()){
                val okta = inputOktal.toInt(8)
                val desimal = okta.toString(10)
                input_decimal.setText(desimal)
                val biner = okta.toString(2)
                input_binary.setText(biner)
                val hexa = okta.toString(16).toUpperCase()
                input_hexa.setText(hexa)

            } else if (inputHexa.isNotEmpty()){
                val hexa = inputHexa.toInt(16)
                val desimal = hexa.toString(10)
                input_decimal.setText(desimal)
                val biner = hexa.toString(2)
                input_binary.setText(biner)
                val okta = hexa.toString(8)
                input_octal.setText(okta)

            }

        }

        if(v.id == R.id.btn_clear){
            val zero = null
            inputDec.setText(zero)
            inputBin.setText(zero)
            inputOct.setText(zero)
            inputHex.setText(zero)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean{
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_profile, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem) : Boolean {
        when (item.itemId) {
            R.id.open_profile -> {
                val About = Intent(this@MainActivity, About::class.java)

                startActivity(About)
                return true
            }
        }
        return false
    }
}


