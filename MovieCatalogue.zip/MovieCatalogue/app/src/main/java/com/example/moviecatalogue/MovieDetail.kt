package com.example.moviecatalogue

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class MovieDetail : AppCompatActivity() {

    companion object {
        const val EXTRA_MOVIE ="extra_movie"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_movie_detail)

        val detTittle : TextView = findViewById(R.id.det_title)
        val detDesc :  TextView = findViewById(R.id.det_desc)
        val detImg : ImageView = findViewById(R.id.det_img)

        val movie = intent.getParcelableExtra(EXTRA_MOVIE) as Movie

        val tittle = movie.name
        val desc = movie.description
        val Image = movie.photo

        detTittle.text = tittle
        detDesc.text = desc
        detImg.setImageResource(Image)


    }
}
