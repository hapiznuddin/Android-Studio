package com.example.moviecatalogue

import android.os.Parcel
import android.os.Parcelable
import kotlinx.android.parcel.Parcelize
@Parcelize
data class Movie (
    var name : String? ,
    var description : String? ,
    var photo : Int = 0

) : Parcelable
