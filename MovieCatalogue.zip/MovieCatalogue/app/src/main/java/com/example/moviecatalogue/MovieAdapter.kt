package com.example.moviecatalogue

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.view.menu.MenuView
class MovieAdapter internal constructor(private val context:Context) : BaseAdapter(){

    internal var movies = arrayListOf<Movie>()

    override fun getItem(i: Int): Any = movies[i]

    override fun getItemId(i: Int): Long = i.toLong()

    override fun getCount(): Int = movies.size

    override fun getView(position: Int, view: View?, viewGroup: ViewGroup): View {
        var itemView = view
        if (itemView == null) {
            itemView = LayoutInflater.from(context).inflate(R.layout.item_movie, viewGroup,false)
        }
        var viewHolder = ViewHolder(itemView as View)

        val movie = getItem(position) as Movie
        viewHolder.bind(movie)
        return itemView
    }

    private inner class ViewHolder internal constructor(view: View) {

        private val txtName: TextView = view.findViewById(R.id.mov_tittle)
        private val txtdesc: TextView = view.findViewById(R.id.mov_desc)
        private val imgPhoto: ImageView = view.findViewById(R.id.img_pict)

        internal fun bind(movie: Movie) {
            txtName.text = movie.name
            txtdesc.text = movie.description
            imgPhoto.setImageResource(movie.photo)
        }
    }
}
